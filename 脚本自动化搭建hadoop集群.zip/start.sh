#!/bin/bash
echo -e '————————————————————————————————\e[41m正在格式化文件系统\e[0m——————————————————————————————————'
rm -rf /linzhensong/servers/hadoop/tmp
slave1=`sed -n '4p' /linzhensong/iphhostname.txt`
slave2=`sed -n '6p' /linzhensong/iphhostname.txt`
ssh $slave1 "rm -rf /linzhensong/servers/hadoop/tmp"
ssh $slave2 "rm -rf /linzhensong/servers/hadoop/tmp"
hdfs namenode -format
echo -e '格式化完成'
sleep 1
echo -e '————————————————————————————————\e[41m正在为您启动hadoop集群\e[0m——————————————————————————————————'
start-dfs.sh
start-yarn.sh

