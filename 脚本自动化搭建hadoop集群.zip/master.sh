#!/bin/bash
echo -e '————————————————————————————————\e[41m请设置主机名\e[0m————————————————————————————————'
echo '请输入主节点主机名 从节点1主机名 从节点2主机名'
echo '例如：hadoop01 hadoop02 hadoop03 用空格隔开'
while true
do
	read -ep '' master slave1 slave2



	if [ -z $slave2 ]
		then
		echo -e '请输入三个主机名'
	else
		echo -e '\e[37m第一台主机名为\e[0m''\e[31m' $master'\e[0m'
                echo -e '\e[37m第二台主机名为\e[0m''\e[31m' $slave1'\e[0m'
                echo -e '\e[37m第三台主机名为\e[0m''\e[31m' $slave2'\e[0m'
		sleep 1
		break
	fi
done

echo -e '————————————————————————————————\e[41m请设置IP地址\e[0m————————————————————————————'
echo -e '\e[31m警告：如果使用的是远程连接工具（Xshell），使用此脚本，修改IP，会导致连接断开！！！\n那么请输入此Xshell连接用的IP，保持IP不变即可\e[0m'
echo '请输入主节点IP 从节点1IP 从节点2IP'
echo '例如：192.168.32.211 192.168.32.212 192.168.32.213 用空格隔开'
while true
do
        read -ep '' masterip slave1ip slave2ip



        if [ -z $slave2ip ]
                then
                echo -e '请输入三个主机名'
        else
                echo -e '\e[37m第一台IP为\e[0m''\e[31m' $masterip'\e[0m'
                echo -e '\e[37m第二台IP为\e[0m''\e[31m' $slave1ip'\e[0m'
                echo -e '\e[37m第三台IP为\e[0m''\e[31m' $slave2ip'\e[0m'
                sleep 1
                break
        fi


done


echo -e '————————————————————————————————\e[41m修改本机主机名为\e[0m'$master'————————————————'
sleep 0.5
echo -e '\e[37msed -i '/^HOSTNAME=/cHOSTNAME=''${master}' /etc/sysconfig/network		修改主机名为'${master}'\e[0m'
sed -i '/^HOSTNAME=/cHOSTNAME='${master} /etc/sysconfig/network
echo -e '\e[37mhostname'${master}'							使主机名立即生效\e[0m'
hostname ${master}
echo -e '\e[37mhostname								查看主机名\e[0m'
hostname
sleep 1


echo -e '————————————————————————————————\e[41m修改本机IP地址为\e[0m'$masterip'——————————————————'
echo -e '\e[37mecho 'BOOTPROTO=static' >> /etc/sysconfig/network-scripts/ifcfg-eth0	使用固定IP\e[0m'
sed -i '/BOOTPROTO=/d' /etc/sysconfig/network-scripts/ifcfg-eth0
echo 'BOOTPROTO=static' >> /etc/sysconfig/network-scripts/ifcfg-eth0
echo -e '\e[37mecho 'IPADDR='${masterip} >> /etc/sysconfig/network-scripts/ifcfg-eth0	设置IP地址\e[0m'
sed -i '/IPADDR=/d' /etc/sysconfig/network-scripts/ifcfg-eth0
echo 'IPADDR='${masterip} >> /etc/sysconfig/network-scripts/ifcfg-eth0
echo -e '\e[37mservice network restart							重启网络服务，请稍等。。。若xshell断开连接，请设置连接用的IP，保持IP不变'
service network restart


echo -e '————————————————————————————————\e[41m配置主机名和IP映射\e[0m——————————————————————————'
delmaster=`sed -n '1p' /linzhensong/ip.txt`
delslave1=`sed -n '2p' /linzhensong/ip.txt`
delslave2=`sed -n '3p' /linzhensong/ip.txt`
sleep 0.5
rm -rf /linzhensong
mkdir -p /linzhensong/servers
touch /linzhensong/ip.txt
touch /linzhensong/iphhostname.txt
echo $masterip $master >> /linzhensong/ip.txt
echo $slave1ip $slave1 >> /linzhensong/ip.txt
echo $slave2ip $slave2 >> /linzhensong/ip.txt
sed -i "/$delmaster/d" /etc/hosts
sed -i "/$delslave1/d" /etc/hosts
sed -i "/$delslave2/d" /etc/hosts
echo '将'$masterip $master '添加到/etc/hosts'
echo '将'$slave1ip $slave1 '添加到/etc/hosts'
echo '将'$slave2ip $slave2 '添加到/etc/hosts'
echo $masterip $master >> /etc/hosts
echo $slave1ip $slave1 >> /etc/hosts
echo $slave2ip $slave2 >> /etc/hosts
sleep 1
echo -e $masterip'\n'$master'\n'$slave1ip'\n'$slave1'\n'$slave2ip'\n'$slave2 >> /linzhensong/iphhostname.txt
echo -e '————————————————————————————————\e[41m网络时间校对\e[0m————————————————————————————————'

sleep 0.5
echo -e '\e[37myum install ntpdate -y							安装ntpdate中\e[0m'
yum install ntpdate -y
echo -e '\e[37mntpdate cn.pool.ntp.org							时间同步中，请稍等...\e[0m'
ntpdate cn.pool.ntp.org
echo -e '\e[37mdate									显示当前时间\e[0m'
date
sleep 1


echo -e '————————————————————————————————\e[41m关闭防火墙\e[0m——————————————————————————————————'
sleep 0.5
echo -e '\e[37mservice iptables stop							停止防火墙服务\e[0m'
service iptables stop
echo -e '\e[37mchkconfig iptables off							禁止防火墙开机自启\e[0m'
chkconfig iptables off
echo -e '\e[37mservice iptables status							查看防火墙运行状态\e[0m'
service iptables status
sleep 1


echo -e '————————————————————————————————\e[41m关闭selinux\e[0m—————————————————————————————————'
sleep 0.5
echo -e '\e[37msed -i '/SELINUX=enforcing/c#SELINUX=enforcing' /etc/selinux/config	注释SELINUX=enforcing\e[0m'
sed -i '/SELINUX=enforcing/c#SELINUX=enforcing' /etc/selinux/config
#echo -e '\e[37msed -i'/SELINUX=enforcing/s/^/#/' /etc/selinux/config			#SELINUX=enforcing\e[0m'
#sed -i '/SELINUX=enforcing/s/^/#/' /etc/selinux/config
echo -e '\e[37msed -i '/SELINUX=enforcing/a SELINUX=disabled' /etc/selinux/config	添加SELINUX=disabled\e[0m'
disablednum=`cat /etc/selinux/config|grep SELINUX=disabled -c`
if [ $disablednum -eq 0 ]
	then
	sed -i '/SELINUX=enforcing/a SELINUX=disabled' /etc/selinux/config
else
	echo -e 'SELINUX=disabled'
fi
sleep 1




echo -e '————————————————————————————————\e[41m安装JDK\e[0m—————————————————————————————————————'
sleep 0.5
#统计找到的jdk安装包数量
jdknum=`find / -name '*jdk*.tar.gz'|wc -l`
echo -e '\e[33m为您查询到'$jdknum'个jdk的安装包\e[0m'
#列出带有序号的jdk安装包列表
for (( i=1;i<=$jdknum;i++ ))
do
	findjdk=`find / -name '*jdk*.tar.gz'|grep -v 林振松 -n |grep $i:`
	echo -e '\e[33m' $findjdk'\e[0m'
done

if [ $jdknum -eq 1 ]
	then
	echo '因为只查询到一个安装包，将默认为您安装此包'
	echo -e '\e[37mtar -zxvf $findjdk1 -C /linzhensong/servers				  开始解压jdk到/linzhensong/servers\e[0m'
	sleep 2
	findjdk1=`find / -name '*jdk*.tar.gz'`
	tar -zxvf $findjdk1 -C /linzhensong/servers
	echo ‘解压完成’
	sleep 2
elif [ $jdknum -eq 0 ]
	then
	echo -e '\e[31m请导入格式为*jdk*.tar.gz的安装包;安装中断！\e[0m'
	sleep 2
	exit
else
	echo '找到多个jdk安装包，请键入需要安装的jdk所对应的的数字，数字可选范围：1~'$jdknum 然后回车
while true
do
read user
case $user in
1)     
	        jdk1=`find / -name '*jdk*.tar.gz'|sed -n '1p'`
                echo '您选择的jdk安装包为 '${jdk1}
                sleep 1.5
                echo '将自动为您安装' ${jdk1}
                sleep 1.5
                tar -zxvf $jdk1 -C /linzhensong/servers
		break  
;;
2)
        if [ $user -le $jdknum ]
                then
		jdk2=`find / -name '*jdk*.tar.gz'|sed -n '2p'`
		echo '您选择的jdk安装包为 '${jdk2}
		sleep 1.5
		echo '将自动为您安装' ${jdk2}
		sleep 1.5
		tar -zxvf $jdk2 -C /linzhensong/servers
		break
        else
                echo $user'不是有效项,请输入 1~'${jdknum}'之间的数'
        fi
;;
3)	if [ $user -le $jdknum ]
                then
                jdk3=`find / -name '*jdk*.tar.gz'|sed -n '3p'`
                echo '您选择的jdk安装包为 '${jdk3}
                sleep 1.5
                echo '将自动为您安装' ${jdk3}
                sleep 1.5
                tar -zxvf $jdk3 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${jdknum}'之间的数'
        fi
;;
4)      if [ $user -le $jdknum ]
                then
                jdk4=`find / -name '*jdk*.tar.gz'|sed -n '4p'`
                echo '您选择的jdk安装包为 '${jdk4}
                sleep 1.5
                echo '将自动为您安装' ${jdk4}
                sleep 1.5
                tar -zxvf $jdk4 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${jdknum}'之间的数'
        fi
;;
5)      if [ $user -le $jdknum ]
                then
                jdk5=`find / -name '*jdk*.tar.gz'|sed -n '5p'`
                echo '您选择的jdk安装包为 '${jdk5}
                sleep 1.5
                echo '将自动为您安装' ${jdk5}
                sleep 1.5
                tar -zxvf $jdk4 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${jdknum}'之间的数'
        fi
;;
6)      if [ $user -le $jdknum ]
                then
                jdk6=`find / -name '*jdk*.tar.gz'|sed -n '6p'`
                echo '您选择的jdk安装包为 '${jdk6}
                sleep 1.5
                echo '将自动为您安装' ${jdk6}
                sleep 1.5
                tar -zxvf $jdk6 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${jdknum}'之间的数'
        fi
;;
7)      if [ $user -le $jdknum ]
                then
                jdk7=`find / -name '*jdk*.tar.gz'|sed -n '7p'`
                echo '您选择的jdk安装包为 '${jdk7}
                sleep 1.5
                echo '将自动为您安装' ${jdk7}
                sleep 1.5
                tar -zxvf $jdk7 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${jdknum}'之间的数'
        fi
;;
8)      if [ $user -le $jdknum ]
                then
                jdk8=`find / -name '*jdk*.tar.gz'|sed -n '8p'`
                echo '您选择的jdk安装包为 '${jdk8}
                sleep 1.5
                echo '将自动为您安装' ${jdk8}
                sleep 1.5
                tar -zxvf $jdk8 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${jdknum}'之间的数'
        fi
;;
9)      if [ $user -le $jdknum ]
                then
                jdk9=`find / -name '*jdk*.tar.gz'|sed -n '9p'`
                echo '您选择的jdk安装包为 '${jdk9}
                sleep 1.5
                echo '将自动为您安装' ${jdk9}
                sleep 1.5
                tar -zxvf $jdk9 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${jdknum}'之间的数'
        fi
;;
10)      if [ $user -le $jdknum ]
                then
                jdk9=`find / -name '*jdk*.tar.gz'|sed -n '10p'`
                echo '您选择的jdk安装包为 '${jdk10}
                sleep 1.5
                echo '将自动为您安装' ${jdk10}
                sleep 1.5
                tar -zxvf $jdk10 -C /linzhensong/servers
                break
        else
                echo ${user}'不是有效项,请输入 1~'${jdknum}'之间的数'
        fi
;;
*)    	echo ${user}'不是有效项,请输入 1~'${jdknum}'之间的数'
;;
esac
done

fi
jyjdk=`ls /linzhensong/servers|grep 'jdk*'`
mv /linzhensong/servers/$jyjdk /linzhensong/servers/jdk


echo -e '————————————————————————————————\e[41m安装hadoop\e[0m——————————————————————————————————'
sleep 0.5
#统计找到的hadoop安装包数量
hadoopnum=`find / -name '*hadoop*.tar.gz'|wc -l`
echo -e '\e[33m为您查询到'$hadoopnum'个hadoop的安装包\e[0m'
#列出带有序号的hadoop安装包列表
for (( i=1;i<=$hadoopnum;i++ ))
do
        findhadoop=`find / -name '*hadoop*.tar.gz'|grep -v 林振松 -n |grep $i:`
        echo -e '\e[33m' $findhadoop'\e[0m'
done

if [ $hadoopnum -eq 1 ]
        then
        echo '因为只查询到一个安装包，将默认为您安装此包'
        sleep 2
        findhadoop1=`find / -name '*hadoop*.tar.gz'`
        tar -zxvf ${findhadoop1} -C /linzhensong/servers
        echo ‘解压完成’
        sleep 2
elif [ $hadoopnum -eq 0 ]
        then
        echo -e '\e[31m请导入格式为*hadoop*.tar.gz的安装包;安装中断！\e[0m'
        sleep 2
        exit
else
        echo '找到多个hadoop安装包，请键入需要安装的hadoop所对应的的数字，数字可选范围：1~'$hadoopnum 然后回车
while true
do
read user
case $user in
1)        if [ $user -le $hadoopnum ]
                then
                hadoop1=`find / -name '*hadoop*.tar.gz'|sed -n '1p'`
                echo '您选择的hadoop安装包为 '${hadoop1}
                sleep 1.5
                echo '将自动为您安装' ${hadoop1}
                sleep 1.5
                tar -zxvf $hadoop1 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${hadoopnum}'之间的数'
        fi
;;
2)
        if [ $user -le $hadoopnum ]
                then
                hadoop2=`find / -name '*hadoop*.tar.gz'|sed -n '2p'`
                echo '您选择的hadoop安装包为 '${hadoop2}
                sleep 1.5
                echo '将自动为您安装' ${hadoop2}
                sleep 1.5
                tar -zxvf $hadoop2 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${hadoopnum}'之间的数'
        fi
;;
3)      if [ $user -le $hadoopnum ]
                then
                hadoop3=`find / -name '*hadoop*.tar.gz'|sed -n '3p'`
                echo '您选择的hadoop安装包为 '${hadoop3}
                sleep 1.5
                echo '将自动为您安装' ${hadoop3}
                sleep 1.5
                tar -zxvf $hadoop3 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${hadoopnum}'之间的数'
        fi
;;
4)      if [ $user -le $hadoopnum ]
                then
                hadoop4=`find / -name '*hadoop*.tar.gz'|sed -n '4p'`
                echo '您选择的hadoop安装包为 '${hadoop4}
                sleep 1.5
                echo '将自动为您安装' ${hadoop4}
                sleep 1.5
                tar -zxvf $hadoop4 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${hadoopnum}'之间的数'
        fi
;;
5)      if [ $user -le $hadoopnum ]
                then
                hadoop5=`find / -name '*hadoop*.tar.gz'|sed -n '5p'`
                echo '您选择的hadoop安装包为 '${hadoop5}
                sleep 1.5
                echo '将自动为您安装' ${hadoop5}
                sleep 1.5
                tar -zxvf $hadoop4 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${hadoopnum}'之间的数'
        fi
;;
6)      if [ $user -le $hadoopnum ]
                then
                hadoop6=`find / -name '*hadoop*.tar.gz'|sed -n '6p'`
                echo '您选择的hadoop安装包为 '${hadoop6}
                sleep 1.5
                echo '将自动为您安装' ${hadoop6}
                sleep 1.5
                tar -zxvf $hadoop6 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${hadoopnum}'之间的数'
        fi
;;
7)      if [ $user -le $hadoopnum ]
                then
                hadoop7=`find / -name '*hadoop*.tar.gz'|sed -n '7p'`
                echo '您选择的hadoop安装包为 '${hadoop7}
                sleep 1.5
                echo '将自动为您安装' ${hadoop7}
                sleep 1.5
                tar -zxvf $hadoop7 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${hadoopnum}'之间的数'
        fi
;;
8)      if [ $user -le $hadoopnum ]
                then
                hadoop8=`find / -name '*hadoop*.tar.gz'|sed -n '8p'`
                echo '您选择的hadoop安装包为 '${hadoop8}
                sleep 1.5
                echo '将自动为您安装' ${hadoop8}
                sleep 1.5
                tar -zxvf $hadoop8 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${hadoopnum}'之间的数'
        fi
;;
9)      if [ $user -le $hadoopnum ]
                then
                hadoop9=`find / -name '*hadoop*.tar.gz'|sed -n '9p'`
                echo '您选择的hadoop安装包为 '${hadoop9}
                sleep 1.5
                echo '将自动为您安装' ${hadoop9}
                sleep 1.5
                tar -zxvf $hadoop9 -C /linzhensong/servers
                break
        else
                echo $user'不是有效项,请输入 1~'${hadoopnum}'之间的数'
        fi
;;
10)      if [ $user -le $hadoopnum ]
                then
                hadoop9=`find / -name '*hadoop*.tar.gz'|sed -n '10p'`
                echo '您选择的hadoop安装包为 '${hadoop10}
                sleep 1.5
                echo '将自动为您安装' ${hadoop10}
                sleep 1.5
                tar -zxvf $hadoop10 -C /linzhensong/servers
                break
        else
                echo ${user}'不是有效项,请输入 1~'${hadoopnum}'之间的数'
        fi
;;
*)      echo ${user}'不是有效项,请输入 1~'${hadoopnum}'之间的数'
;;
esac
done

fi
jyhadoop=`ls /linzhensong/servers|grep 'hadoop*'`
echo -e '\e[37mmv /linzhensong/servers/$jyhadoop /linzhensong/servers/hadoop		重命名'${jyhadoop}'为hadoop'
mv /linzhensong/servers/$jyhadoop /linzhensong/servers/hadoop
echo -e '\e[37m									ls /linzhensong/servers/查看hadoop重命名是否成功\e[0m'
ls /linzhensong/servers/

echo -e '————————————————————————————————\e[41m配置Java和hadoop环境变量\e[0m——————————————————————————————————'
sleep 0.5
echo -e '\e[37msed -i '/JAVA_HOME/d' /etc/profile                                       删除旧的java环境变量，若果有的话\e[0m'
sed -i '/JAVA_HOME/d' /etc/profile
echo -e '\e[37msed -i '/HADOOP_HOME/d' /etc/profile                                     删除旧的hadoop环境变量，若果有的话\e[0m'
sed -i '/HADOOP_HOME/d' /etc/profile
#setjava
echo 'export JAVA_HOME=/linzhensong/servers/jdk' >> /etc/profile
echo 'export PATH=$PATH:$JAVA_HOME/bin' >> /etc/profile
echo 'export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar' >> /etc/profile
#sethadoop
echo 'export HADOOP_HOME=/linzhensong/servers/hadoop' >> /etc/profile
echo 'export PATH=$PATH:$HADOOP_HOME/bin:$HADOOP_HOME/sbin' >> /etc/profile
#刷新环境变量
echo -e '\e[37msource /etc/profile                                                      刷新环境变量\e[0m'
source /etc/profile
sleep 1


echo -e '————————————————————————————————\e[41mHadoop集群配置\e[0m————————————————————————————————————————————'
echo -e '                                                                       \e[37mvi hadoop-env.sh \e[0m'
sed -i '/export JAVA_HOME=${JAVA_HOME}/cexport JAVA_HOME=/linzhensong/servers/jdk' /linzhensong/servers/hadoop/etc/hadoop/hadoop-env.sh


echo -e '                                                                       \e[37mvi core-site.xml\e[0m'
sed -i '/^<configuration>/,/^<\/configuration>/d' /linzhensong/servers/hadoop/etc/hadoop/core-site.xml
echo -e '<configuration>\n\t<property>\n\t\t<name>fs.defaultFS</name>\n\t\t<value>hdfs://'${master}':9000</value>\n\t</property>\n\t<property>\n\t\t<name>hadoop.tmp.dir</name>\n\t\t<value>/linzhensong/servers/hadoop/tmp</value>\n\t</property>\n</configuration>
'  >> /linzhensong/servers/hadoop/etc/hadoop/core-site.xml


echo -e '                                                                       \e[37mvi hdfs-site.xml\e[0m'
sed -i '/^<configuration>/,/^<\/configuration>/d' /linzhensong/servers/hadoop/etc/hadoop/hdfs-site.xml
echo -e '<configuration>\n\t<property>\n\t\t<name>dfs.replication</name>\n\t\t<value>3</value>\n\t</property>\n\t<property>\n\t\t<name>dfs.namenode.secondary.http-address</name>\n\t\t<value>'${slave1}':50090</value>\n\t</property>\n</configuration>' >> /linzhensong/servers/hadoop/etc/hadoop/hdfs-site.xml



echo -e '                                                                       \e[37mvi mapred-site.xml\e[0m'
cp /linzhensong/servers/hadoop/etc/hadoop/mapred-site.xml.template /linzhensong/servers/hadoop/etc/hadoop/mapred-site.xml
sed -i '/^<configuration>/,/^<\/configuration>/d' /linzhensong/servers/hadoop/etc/hadoop/mapred-site.xml
echo -e '<configuration>\n\t<property>\n\t\t<name>mapreduce.framework.name</name>\n\t\t<value>yarn</value>\n\t</property>\n</configuration>
' >>  /linzhensong/servers/hadoop/etc/hadoop/mapred-site.xml





echo -e '                                                                       \e[37mvi yarn-site.xml\e[0m'
sed -i '/^<configuration>/,/^<\/configuration>/d' /linzhensong/servers/hadoop/etc/hadoop/yarn-site.xml
echo -e '<configuration>\t<property>\n\t\t<name>yarn.nodemanager.resource.memory-mb</name>\n\t\t<value>1600</value>\n\t</property>\n\t<property>
\t\t<name>yarn.nodemanager.resource.cpu-vcores</name>\n\t\t<value>1</value>\n\t</property>\n\t<property>\n\t\t<name>yarn.resourcemanager.hostname</name>\n\t\t<value>'${master}'</value>\n\t</property>\n\t<property>\n\t\t<name>yarn.nodemanager.aux-services</name>\n\t\t<value>mapreduce_shuffle</value>\n\t</property>\n</configuration>
' >>/linzhensong/servers/hadoop/etc/hadoop/yarn-site.xml

echo -e '                                                                       \e[37mvi slaves\e[0m'
sed -i '/localhost/d' /linzhensong/servers/hadoop/etc/hadoop/slaves
echo -e ${master}'\n'$slave1'\n'${slave2} >>/linzhensong/servers/hadoop/etc/hadoop/slaves

 .  /etc/profile

source /etc/profile

echo -e "\033[37;34;5mOJBK\033[39;49;0m"

echo '已完成主节点配置，现在可以去克隆从节点了'
