#!/bin/bash


rm -rf ~/.ssh
echo -e '————————————————————————————————\e[41m正在主节点生成公钥和秘钥\e[0m——————————————————————————————————'
echo -e '\e[41m请连续键入三个Enter以继续\e[0m'
ssh-keygen -t rsa



echo -e '————————————————————————————————\e[41m正在设置免密请按要求操作\e[0m——————————————————————————————————'
echo -e '\e[41m请输入yes然后输入hadoop01的密码\e[0m'
echo yes|ssh-copy-id hadoop01
echo -e '\e[41m请输入yes然后输入hadoop02的密码\e[0m'
echo yes|ssh-copy-id hadoop02
echo -e '\e[41m请输入yes然后输入hadoop03的密码\e[0m'
echo yes|ssh-copy-id hadoop03


