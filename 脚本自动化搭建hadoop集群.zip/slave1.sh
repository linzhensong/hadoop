#!/bin/bash
slave1ip=`sed -n '3p' /linzhensong/iphhostname.txt`
slave1=`sed -n '4p' /linzhensong/iphhostname.txt`

echo -e '————————————————————————————————\e[41m修改主机名\e[0m——————————————————————————————————'
sed -i '/^HOSTNAME=/cHOSTNAME='"$slave1" /etc/sysconfig/network
slave1hostname=`cat /etc/sysconfig/network|grep HOSTNAME=`
echo -e '\e[31m已成功修改主机名为'$slave1hostname'\e[0m' 



echo -e '————————————————————————————————\e[41m配置网络\e[0m——————————————————————————————————'
rm -rf /etc/udev/rules.d/70-persistent-net.rules
sed -i '/HWADDR=/d' /etc/sysconfig/network-scripts/ifcfg-eth0
echo -e '\e[37m已更正MAC地址\e[0m'
sed -i '/^IPADDR=/cIPADDR='"$slave1ip" /etc/sysconfig/network-scripts/ifcfg-eth0
echo -e '\e[41m系统将在3秒后自动重启\e[0m'
sleep 1
echo -e '\e[31m3\e[0m'
sleep 1
echo -e '\e[31m2\e[0m'
sleep 1
echo -e '\e[31m1\e[0m'
sleep 1
echo -e '\e[31mreboot...\e[0m'
sleep 1
reboot

